- Website | https://la-mesh.link
- Meetup page | https://www.meetup.com/Los-Angeles-Wi-Fi-Meetup/ 
- Github | https://github.com/lameshnet 

---
