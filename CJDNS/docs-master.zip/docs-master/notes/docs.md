Everything ought to be translated at some point (hopefully when it's somewhat finished)

- Russian (mungell volunteered)
- Portuguese (fiatjaf volunteered)
- Spanish
- French?
- German?
- ???


what needs docs?

- contrib/


especially useful stuff

- contrib/python/peerStats - shows a list of your peers and their connection status as well as byte counts
- contrib/python/cjdnsadminmaker.py - generates .cjdnsadmin for use with other scripts


Tutorials specifically for newbs

- using IRC
- community guidelines


stuff on OSX

- http://couch.syrinxist.org:9001/p/osx


General Math and stuff behind cjdns security and network architecture

- http://couch.syrinxist.org:9001/p/howCjdnsWorks


"best practices for web development on hyperboria"

- not including google APIs
- ssl (certificate authority data leak)  CAs are bad. NSA probably has most of the CA keys.
- assuming everyone is going to try to hack you.. because they would on clearnet anyway
- listing a server's ipv6 in a conspicuous location (opt out of ICANN)
- listing of available services on any given node (even a simple webserver saying who you are is kinda nice, there exists no way to tell who's who by IP)

Good Ideas(tm)

- Turn off password auth if you are running sshd on hype. Especially if you have crap passwords. http://couch.syrinxist.org/security ah

CJDNS related resources:  http://couch.syrinxist.org/links

links to....
- buildbots?
- blogs?
- hype services?
- related clearnet services?

Proxying into your machine

- socks? <- mungell
- squid?
- etc...
