The following is just a draft of what our landing page _could_ look like.
The steps are just off the top of my head, based off of my experience walking people through setup on EFNet.

Lots of this info is already in the repo, but it's scattered all over, and ideally we need just **one** document that can get people going if they read through it.

## Getting going with cjdns

1. what is it?
2. how can you install it? -> OS/Distro && hardware combos (click to go to appropriate page)
  + get tools
  + get source
  + build -> go back to main page, all OS/distro stuff _should_ be taken care of
3. generate a conf
  + edit your conf
  + find && add peers
4. Now you should be on the net...
  + testing whether you're connected
  + troubleshooting if you're not
    * do you have a tun device?
    * is your command line working? (ping6, curl)
    * is your chrome/firefox working?
5. cool, now you're on
  + secure your device
  + get on hypeirc
  + find something to do
6. ???
7. Profit

:D


