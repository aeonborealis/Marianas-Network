# Proposal for small daemon, nodeinfo-ng

+ small daemon
  - serves:
    + nodeinfo.json
      + list of services
      + hostname
      + owner contact information
      + "open to peering" option?
      + other nodes operated by same owner
      + robots.txt
  - dumpTable (reuse the remnants of HDB?)
  - Direct Peers
  - cjdns log/debug info
  - system info

Note that some could be optional, and that **THIS IS A WORK IN PROGRESS**
