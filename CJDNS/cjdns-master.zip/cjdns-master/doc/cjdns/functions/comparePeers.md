#### static int comparePeers(const struct [Node_Link][]* la, const struct [Node_Link][]* lb)

if the number of leading bits of cannicalLabel for la and lb are equal  
return 0

after reverseing the order of every bit in a and b  
if a is less than b
return positive  
else  
return negitive
