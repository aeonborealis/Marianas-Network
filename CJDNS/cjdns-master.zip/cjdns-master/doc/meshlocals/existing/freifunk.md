# Freifunk

There are individuals running cjdns nodes on the Freifunk networks in Leipzig,
Berlin, and Hamburg.

- kpcyrd
- larsg

You can find both of us in #cjdns on EFnet, hackint and HypeIRC.

More information about Freifunk: https://freifunk.net
