# Meshnet Polska

**Website:** [meshnet.pl](https://meshnet.pl)

See also [mesh page on Hackerspace Kraków wiki](http://wiki.hackerspace-krk.pl/projekty/mesh).
