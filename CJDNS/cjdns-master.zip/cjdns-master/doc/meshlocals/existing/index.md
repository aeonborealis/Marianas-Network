# List of Known Meshlocals

These are some physical mesh networks that use cjdns in The Real World. Add
yours by submitting a pull request.

 * **Europe**
  * [Freifunk: Leipzig, Berlin, Hamburg](freifunk.md)
  * [Poland, especially Kraków](poland.md)
 * **United States**
  * California
    * [San Diego](sandiego.md)
  * [Virginia](virginia.md)
  * Washington
    * [Seattle](seattle.md)
 * **Canada**
  * Ontario
    * [Toronto](toronto.md)
