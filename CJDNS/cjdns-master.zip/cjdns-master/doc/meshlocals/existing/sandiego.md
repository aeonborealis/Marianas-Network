San Diego Meshnet
============

**[Website](http://sdmesh.net/)**

**[Mailing List](http://lists.projectmesh.net/cgi-bin/mailman/listinfo/sandiego)**
