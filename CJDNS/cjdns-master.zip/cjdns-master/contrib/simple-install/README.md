# Simple install

Tested on ubuntu 18.04LTS

```
git clone https://github.com/cjdelisle/cjdns.git
cd cjdns/
./do
sudo ./contrib/simple-install/cjdns-install.sh
```

You can edit configuration in `/etc/cjdroute.conf` and restart cjdns service with `sudo systemctl restart cjdns.service`.

